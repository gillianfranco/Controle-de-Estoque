<?php
	$pdo = new PDO ("mysql: host=localhost; dbname=stock", "root", "");
	$pdo -> exec ("SET NAMES 'UTF8'");
?>